---
layout: post
title: SteamJam Incoming!
---

So... I've joined a game jam.

![alt text](https://img.itch.zone/aW1nLzIwNzkzNzMucG5n/original/pyundq.png "Logo Title Text 1")

The theme is "Pong" oddly enough, so I've decided to make a story/platformer about a pong ball who was never hit back.

You can find more information from the game on itch.io at this link. [The Unreturned](https://dynamicdonkey.itch.io/the-unreturned)

I'll keep you guys updated!
