---
layout: post
title: Starting my first game!
---

New blog, first post, new project!

Hey y'all! I've started working on my first game along with a close friend, Landis Buckley. He does all the art because I'm bad at it. Programmings is my jam.

It's a top-down RPG with a basic 16x16 artstyle similar to the Legend of Zelda. The project will be fully open source, too!

[Screenshot](https://i.imgur.com/64b8yAG.gifv)

Hopefully that image worked, it's a short gif of the current menuy. Not dont yet, and the textures are slightly broken, but it'll do.

You can find the release page at [this link.](https://dynamicdonkey.github.io/RPG-Game/index.html)
