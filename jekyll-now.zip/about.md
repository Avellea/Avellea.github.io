---
layout: page
title: About
permalink: /about/
---

Hi there! I'm a hobbyist game developer and programmer. I'm also an amateur radio operator!

### More Information

I started programming in 2012 when I was first introduced to Linux by my uncle. He set me off to learn Bash, Python, and whatever my searches led me to. Now, in 2019, I'm lead electrician on my highschool Robotics team, I'm a Java/GDScript/JavaScript/Web developer, and amateur radio operator.
